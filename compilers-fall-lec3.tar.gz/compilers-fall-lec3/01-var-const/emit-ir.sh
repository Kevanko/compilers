#!/bin/sh

clang -O0 -S -emit-llvm ./prog.cpp
