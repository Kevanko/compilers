#!/bin/sh

clang++ -Xclang -ast-dump -fsyntax-only ./prog.cpp


